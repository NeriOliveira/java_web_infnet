package br.edu.infnet.appcoleta_jdk11.model.repository;

/*
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import br.edu.infnet.appcoleta_jdk11.model.negocio.Solicitante;

@Repository
public interface SolicitanteRepository extends CrudRepository<Solicitante, Integer>{
	
	//incluir
	
	//excluir
	
	//alterar
	
	//recuperar todos
	
	//recuperar um

}
*/
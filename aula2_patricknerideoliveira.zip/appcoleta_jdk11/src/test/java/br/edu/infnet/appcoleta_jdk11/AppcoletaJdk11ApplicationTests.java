package br.edu.infnet.appcoleta_jdk11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppcoletaJdk11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
